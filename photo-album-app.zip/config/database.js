// config/database.js
// 引入Sequelize模块
const { Sequelize } = require('sequelize');

// 创建Sequelize实例，配置数据库连接信息
const sequelize = new Sequelize(
  'photo_album',  // 数据库名（第一步在MySQL里创建的）
  'root',         // MySQL用户名（默认是root，如果你改了用户名就填你的）
  'YYhh125110!',// 重点：替换成你自己的MySQL登录密码！！！
  {
    host: 'localhost', // 数据库地址（本地开发默认是localhost）
    dialect: 'mysql',  // 数据库类型（这里是MySQL）
    port: 3306,        // MySQL默认端口（如果改了端口就填你的）
    logging: false,    // 关闭SQL日志（开发时想看SQL可以改成true）
    // 连接池配置（可选，优化性能）
    pool: {
      max: 5,          // 连接池最大连接数
      min: 0,          // 最小连接数
      acquire: 30000,  // 获取连接的超时时间（毫秒）
      idle: 10000      // 连接空闲超时时间（毫秒）
    }
  }
);

// 测试数据库连接的函数
async function testConnection() {
  try {
    // 尝试连接数据库
    await sequelize.authenticate();
    console.log('✅ 数据库连接成功！');

    // 查询MySQL版本（验证是否真的连上了）
    const [versionResult] = await sequelize.query('SELECT VERSION() as mysql_version');
    console.log('🔍 MySQL数据库版本：', versionResult[0].mysql_version);
  } catch (error) {
    // 连接失败时打印错误
    console.error('❌ 数据库连接失败：', error.message);
  }
}

// 导出Sequelize实例和测试函数（供其他文件使用）
module.exports = { sequelize, testConnection };