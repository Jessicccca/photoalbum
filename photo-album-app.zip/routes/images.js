// routes/images.js
const express = require('express');
const router = express.Router();
const { sequelize, Image, Comment, Like } = require('../models'); // 引入sequelize
const authMiddleware = require('../middleware/authMiddleware');

// 1. GET /api/images：获取图片列表（含评论数、点赞数）
router.get('/', async (req, res) => {
  try {
    const images = await Image.findAll({
      attributes: [
        'id', 'title', 'url', 'description', 'userId', 'createdAt',
        // 子查询：计算评论数
        [sequelize.literal('(SELECT COUNT(*) FROM comments WHERE comments.imageId = Image.id)'), 'commentCount'],
        // 子查询：计算点赞数
        [sequelize.literal('(SELECT COUNT(*) FROM likes WHERE likes.imageId = Image.id)'), 'likeCount']
      ],
      order: [['createdAt', 'DESC']]
    });
    
    res.status(200).json({
      success: true,
      data: images
    });
  } catch (error) {
    console.error('获取图片列表失败：', error); // 打印错误到终端
    res.status(500).json({
      success: false,
      message: '获取图片列表失败',
      error: error.message // 返回错误信息（开发环境用）
    });
  }
});

// 2. POST /api/images/:id/comments：发表评论（需认证）
router.post('/:id/comments', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { content } = req.body;
    const userId = req.userId;
    
    const image = await Image.findByPk(id);
    if (!image) {
      return res.status(404).json({
        success: false,
        message: '图片不存在'
      });
    }
    
    const comment = await Comment.create({
      content,
      imageId: id,
      userId
    });
    
    res.status(201).json({
      success: true,
      message: '评论发表成功',
      data: comment
    });
  } catch (error) {
    console.error('发表评论失败：', error);
    res.status(500).json({
      success: false,
      message: '发表评论失败',
      error: error.message
    });
  }
});

// 3. POST /api/images/:id/likes：点赞/取消点赞（需认证）
router.post('/:id/likes', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.userId;
    
    const image = await Image.findByPk(id);
    if (!image) {
      return res.status(404).json({
        success: false,
        message: '图片不存在'
      });
    }
    
    const existingLike = await Like.findOne({
      where: { imageId: id, userId }
    });
    
    if (existingLike) {
      await existingLike.destroy();
      return res.status(200).json({
        success: true,
        message: '取消点赞成功',
        liked: false
      });
    } else {
      await Like.create({ imageId: id, userId });
      return res.status(200).json({
        success: true,
        message: '点赞成功',
        liked: true
      });
    }
  } catch (error) {
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({
        success: false,
        message: '你已点赞过该图片'
      });
    }
    console.error('点赞操作失败：', error);
    res.status(500).json({
      success: false,
      message: '点赞操作失败',
      error: error.message
    });
  }
});

// 新增：获取图片评论列表
router.get('/:id/comments', async (req, res) => {
  try {
    const { id } = req.params;
    
    const comments = await Comment.findAll({
      where: { imageId: id },
      order: [['createdAt', 'DESC']]
    });
    
    res.status(200).json({
      success: true,
      data: comments
    });
  } catch (error) {
    console.error('获取评论失败：', error);
    res.status(500).json({
      success: false,
      message: '获取评论失败',
      error: error.message
    });
  }
});

// 新增：检查点赞状态
router.get('/:id/likes/check', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.userId;
    
    const like = await Like.findOne({
      where: { imageId: id, userId }
    });
    
    res.status(200).json({
      success: true,
      data: { liked: !!like }
    });
  } catch (error) {
    console.error('检查点赞状态失败：', error);
    res.status(500).json({
      success: false,
      message: '检查点赞状态失败',
      error: error.message
    });
  }
});

module.exports = router;