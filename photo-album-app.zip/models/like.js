// models/like.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Like = sequelize.define('Like', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  // 关联图片ID
  imageId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'images',
      key: 'id'
    }
  },
  // 点赞用户ID
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false
  }
}, {
  tableName: 'likes',
  timestamps: true,
  // 联合唯一索引：防止同一用户重复点赞同一图片
  indexes: [
    {
      unique: true,
      fields: ['imageId', 'userId']
    }
  ]
});

module.exports = Like;