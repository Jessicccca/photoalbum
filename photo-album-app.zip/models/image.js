// models/image.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Image = sequelize.define('Image', {
  // 图片ID（主键，自增）
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  // 图片标题
  title: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  // 图片URL/路径
  url: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  // 上传用户ID（关联用户表，这里简化先存ID）
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  // 图片描述（可选）
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  // 表名（默认复数，这里指定单数）
  tableName: 'images',
  // 自动添加createdAt和updatedAt字段
  timestamps: true
});

module.exports = Image;