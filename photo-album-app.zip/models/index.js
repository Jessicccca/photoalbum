// models/index.js
const { sequelize } = require('../config/database');
const Image = require('./image');
const Comment = require('./comment');
const Like = require('./like');

// 建立模型关联
// 1. Image与Comment：一张图片有多个评论（一对多）
Image.hasMany(Comment, { foreignKey: 'imageId', onDelete: 'CASCADE' });
Comment.belongsTo(Image, { foreignKey: 'imageId' });

// 2. Image与Like：一张图片有多个点赞（一对多）
Image.hasMany(Like, { foreignKey: 'imageId', onDelete: 'CASCADE' });
Like.belongsTo(Image, { foreignKey: 'imageId' });

// 导出所有模型和sequelize实例
module.exports = {
  sequelize,
  Image,
  Comment,
  Like
};