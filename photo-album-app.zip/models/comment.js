// models/comment.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Comment = sequelize.define('Comment', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  // 评论内容
  content: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  // 关联图片ID
  imageId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'images', // 关联的表名
      key: 'id'
    }
  },
  // 评论用户ID
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false
  }
}, {
  tableName: 'comments',
  timestamps: true
});

module.exports = Comment;