// test-db.js
// 引入config里的测试函数
const { testConnection } = require('./config/database');

// 执行连接测试
testConnection();