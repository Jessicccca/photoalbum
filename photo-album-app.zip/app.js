// app.js - 项目入口文件
const express = require('express');
const cors = require('cors');
const { sequelize } = require('./config/database');
const imageRoutes = require('./routes/images');

// 创建Express应用
const app = express();
const PORT = process.env.PORT || 3000;

// 配置中间件
app.use(cors()); // 允许跨域
app.use(express.static('public')); // 托管静态文件（public文件夹）
app.use(express.json()); // 解析JSON请求体
app.use(express.urlencoded({ extended: true })); // 解析表单请求体

// 挂载路由
app.use('/api/images', imageRoutes);

// 同步数据库模型并启动服务器
sequelize.sync({ force: false })
  .then(() => {
    console.log('✅ 数据库模型同步成功');
    // 启动服务器
    app.listen(PORT, () => {
      console.log(`🚀 服务器运行在 http://localhost:${PORT}`);
      console.log(`📁 静态文件访问地址：http://localhost:${PORT}/uploads/`);
    });
  })
  .catch(error => {
    console.error('❌ 数据库同步失败：', error.message);
  });