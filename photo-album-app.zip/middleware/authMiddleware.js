// middleware/authMiddleware.js
// 简化版认证中间件（实际项目需用JWT/会话验证）
function authMiddleware(req, res, next) {
  // 模拟从请求头获取用户ID（实际应从token解析）
  const userId = req.headers['user-id'];
  
  if (!userId) {
    return res.status(401).json({ message: '未认证，请先登录' });
  }
  
  // 将用户ID挂载到req对象，供后续接口使用
  req.userId = parseInt(userId);
  next();
}

module.exports = authMiddleware;
